name = input("Type your name here:")
print(f"Hello, {name}!")

